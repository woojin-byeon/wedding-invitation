.. _ansible_collections.community.vmware.docsite.vmware_external_doc_links:

*****************************
Other useful VMware resources
*****************************

* `VMware API and SDK Documentation <https://www.vmware.com/support/pubs/sdk_pubs.html>`_
* `Ansible VMware community wiki page <https://github.com/ansible/community/wiki/VMware>`_
* `VMware's official Guest Operating system customization matrix <https://partnerweb.vmware.com/programs/guestOS/guest-os-customization-matrix.pdf>`_
* `VMware Compatibility Guide <https://www.vmware.com/resources/compatibility/search.php>`_
