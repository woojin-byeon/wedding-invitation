/* ═══════════════════════════════════════════════════════
   woojin-world — main.js  (vanilla, no dependencies)
   ═══════════════════════════════════════════════════════ */
(function () {
  'use strict';

  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ── 1. BOOT SEQUENCE ─────────────────────────────── */
  var BOOT = [
    ['[  OK  ] ', 'Reached target Network.'],
    ['[  OK  ] ', 'Started nginx - high performance web server.'],
    ['[  OK  ] ', 'Started certbot renewal timer.'],
    ['[  OK  ] ', 'Mounted /srv/woojin-world.'],
    ['[  OK  ] ', 'Started sshd (key auth only).'],
    ['[  OK  ] ', 'Health check endpoint responding.'],
    ['',         ''],
    ['',         'woojin-world login: portfolio ready.']
  ];

  function boot() {
    var el = document.getElementById('boot-log');
    var box = document.getElementById('boot');
    if (!el || !box) return;

    if (reduce || sessionStorage.getItem('booted')) {
      box.classList.add('boot--done');
      setTimeout(function () { box.remove(); }, 200);
      start();
      return;
    }

    var i = 0;
    (function next() {
      if (i >= BOOT.length) {
        setTimeout(function () {
          box.classList.add('boot--done');
          sessionStorage.setItem('booted', '1');
          setTimeout(function () { box.remove(); }, 600);
          start();
        }, 380);
        return;
      }
      var row = BOOT[i++];
      el.innerHTML += '<span class="ok">' + row[0] + '</span><span class="dim">' + row[1] + '</span>\n';
      setTimeout(next, 130 + Math.random() * 110);
    })();
  }

  /* ── 2. HERO TYPING ───────────────────────────────── */
  var ROLES = [
    'Infrastructure Engineer',
    'DevOps Engineer',
    'Automation Enthusiast',
    'Kubernetes Operator',
    '변우진 / WooJin Byeon'
  ];

  function typer() {
    var el = document.getElementById('typed');
    if (!el) return;
    if (reduce) { el.textContent = ROLES[ROLES.length - 1]; return; }

    var ri = 0, ci = 0, del = false;
    (function tick() {
      var word = ROLES[ri];
      el.textContent = word.slice(0, ci);
      if (!del && ci < word.length) { ci++; setTimeout(tick, 70); }
      else if (!del && ci === word.length) { del = true; setTimeout(tick, 1600); }
      else if (del && ci > 0) { ci--; setTimeout(tick, 34); }
      else { del = false; ri = (ri + 1) % ROLES.length; setTimeout(tick, 320); }
    })();
  }

  /* ── 3. TERMINAL LINE REVEAL ──────────────────────── */
  function termLines() {
    document.querySelectorAll('.term__line').forEach(function (n) {
      var d = parseInt(n.dataset.delay || '0', 10);
      setTimeout(function () { n.classList.add('show'); }, 500 + d * 550);
    });
  }

  /* ── 4. SCROLL REVEAL ─────────────────────────────── */
  function reveal() {
    var targets = document.querySelectorAll(
      '.sec__title,.sec__lead,.about,.card,.proj,.diagram,.runbook,.tl__item,.contact > *'
    );
    targets.forEach(function (n) { n.classList.add('reveal'); });

    if (!('IntersectionObserver' in window)) {
      targets.forEach(function (n) { n.classList.add('in'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e, idx) {
        if (!e.isIntersecting) return;
        setTimeout(function () { e.target.classList.add('in'); }, idx * 70);
        io.unobserve(e.target);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });
    targets.forEach(function (n) { io.observe(n); });
  }

  /* ── 5. SKILL BARS ────────────────────────────────── */
  function bars() {
    var items = document.querySelectorAll('.bars li');
    items.forEach(function (li) {
      var t = document.createElement('i');
      t.className = 'track';
      li.appendChild(t);
    });
    if (!('IntersectionObserver' in window)) {
      items.forEach(function (li) { li.style.setProperty('--w', li.dataset.v + '%'); });
      return;
    }
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return;
        var li = e.target;
        setTimeout(function () {
          li.style.setProperty('--w', li.dataset.v + '%');
        }, 120);
        io.unobserve(li);
      });
    }, { threshold: 0.4 });
    items.forEach(function (li) { io.observe(li); });
  }

  /* ── 6. COUNTERS ──────────────────────────────────── */
  function counters() {
    var nodes = document.querySelectorAll('[data-count]');
    function run(n) {
      var end = parseFloat(n.dataset.count);
      var dec = parseInt(n.dataset.decimal || '0', 10);
      var t0 = performance.now(), dur = 1300;
      (function step(now) {
        var p = Math.min((now - t0) / dur, 1);
        var eased = 1 - Math.pow(1 - p, 3);
        n.textContent = (end * eased).toFixed(dec);
        if (p < 1) requestAnimationFrame(step);
      })(t0);
    }
    if (!('IntersectionObserver' in window)) { nodes.forEach(run); return; }
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return;
        run(e.target); io.unobserve(e.target);
      });
    }, { threshold: 0.5 });
    nodes.forEach(function (n) { io.observe(n); });
  }

  /* ── 7. NAV ───────────────────────────────────────── */
  function nav() {
    var bar = document.getElementById('nav');
    var links = document.querySelector('.nav__links');
    var toggle = document.getElementById('navToggle');

    window.addEventListener('scroll', function () {
      bar.classList.toggle('nav--stuck', window.scrollY > 40);
    }, { passive: true });

    if (toggle) {
      toggle.addEventListener('click', function () { links.classList.toggle('open'); });
      links.addEventListener('click', function (e) {
        if (e.target.tagName === 'A') links.classList.remove('open');
      });
    }
  }

  /* ── 8. FOOTER: year + latency probe ──────────────── */
  function footer() {
    var y = document.getElementById('year');
    if (y) y.textContent = new Date().getFullYear();

    var rtt = document.getElementById('rtt');
    if (!rtt) return;
    var t0 = performance.now();
    fetch('/health', { cache: 'no-store' })
      .then(function (r) {
        var ms = Math.round(performance.now() - t0);
        rtt.textContent = r.ok ? 'rtt ' + ms + 'ms' : 'health ' + r.status;
      })
      .catch(function () { rtt.textContent = 'rtt n/a'; });
  }

  /* ── 9. KONAMI EASTER EGG ─────────────────────────── */
  function egg() {
    var seq = ['ArrowUp','ArrowUp','ArrowDown','ArrowDown','ArrowLeft','ArrowRight','ArrowLeft','ArrowRight','b','a'];
    var pos = 0;
    document.addEventListener('keydown', function (e) {
      pos = (e.key === seq[pos]) ? pos + 1 : 0;
      if (pos !== seq.length) return;
      pos = 0;
      console.log('%c sudo make me a sandwich ', 'background:#3ddc97;color:#06120c;font-weight:700;padding:4px 8px');
      document.body.style.transition = 'filter .6s';
      document.body.style.filter = 'hue-rotate(160deg)';
      setTimeout(function () { document.body.style.filter = ''; }, 1800);
    });
  }

  /* ── boot order ───────────────────────────────────── */
  function start() { typer(); termLines(); reveal(); bars(); counters(); }

  document.addEventListener('DOMContentLoaded', function () {
    nav(); footer(); egg(); boot();
    console.log(
      '%c woojin-world %c infrastructure as code, portfolio as infrastructure ',
      'background:#3ddc97;color:#06120c;font-weight:700;padding:3px 6px',
      'background:#131c26;color:#8fa3b8;padding:3px 6px'
    );
  });
})();
