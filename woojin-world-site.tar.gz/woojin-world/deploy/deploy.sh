#!/usr/bin/env bash
# ════════════════════════════════════════════════════════
#  woojin-world 배포 스크립트  (Rocky Linux 8.10 / nginx)
#  사용법:  sudo ./deploy.sh
# ════════════════════════════════════════════════════════
set -euo pipefail

SITE_ROOT="/srv/woojin-world"
CONF_SRC="$(cd "$(dirname "$0")" && pwd)/woojin-world.conf"
SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BACKUP_DIR="/var/backups/woojin-world"
TS="$(date +%Y%m%d-%H%M%S)"

log() { printf '\033[1;32m[  OK  ]\033[0m %s\n' "$1"; }
err() { printf '\033[1;31m[FAILED]\033[0m %s\n' "$1" >&2; exit 1; }

[[ $EUID -eq 0 ]] || err "root 권한으로 실행하세요 (sudo ./deploy.sh)"

# 1) 기존 사이트 백업
if [[ -d "$SITE_ROOT" ]]; then
  mkdir -p "$BACKUP_DIR"
  tar -czf "${BACKUP_DIR}/site-${TS}.tar.gz" -C "$SITE_ROOT" . 2>/dev/null || true
  log "기존 사이트 백업 → ${BACKUP_DIR}/site-${TS}.tar.gz"
fi

# 2) 파일 배포
mkdir -p "$SITE_ROOT"
rsync -a --delete \
  --exclude 'deploy/' --exclude 'README.md' --exclude '.git/' \
  "${SRC_DIR}/" "$SITE_ROOT/"
log "정적 파일 배포 → $SITE_ROOT"

# 3) 권한 / SELinux 컨텍스트
chown -R nginx:nginx "$SITE_ROOT"
find "$SITE_ROOT" -type d -exec chmod 755 {} \;
find "$SITE_ROOT" -type f -exec chmod 644 {} \;
log "퍼미션 설정 완료"

if command -v getenforce >/dev/null && [[ "$(getenforce)" != "Disabled" ]]; then
  semanage fcontext -a -t httpd_sys_content_t "${SITE_ROOT}(/.*)?" 2>/dev/null || true
  restorecon -Rv "$SITE_ROOT" >/dev/null
  log "SELinux 컨텍스트 적용 (httpd_sys_content_t)"
fi

# 4) nginx 설정 반영
install -m 644 "$CONF_SRC" /etc/nginx/conf.d/woojin-world.conf
log "nginx 설정 배치 → /etc/nginx/conf.d/woojin-world.conf"

nginx -t || err "nginx 설정 문법 오류 — 롤백하세요"
systemctl reload nginx
log "nginx reload 완료"

# 5) 방화벽
if systemctl is-active --quiet firewalld; then
  firewall-cmd --permanent --add-service=http  >/dev/null
  firewall-cmd --permanent --add-service=https >/dev/null
  firewall-cmd --reload >/dev/null
  log "firewalld: http/https 허용"
fi

# 6) 검증
sleep 1
CODE="$(curl -s -o /dev/null -w '%{http_code}' -k https://localhost/health || echo 000)"
[[ "$CODE" == "200" ]] && log "health check 200 OK" || err "health check 실패 (code=$CODE)"

printf '\n\033[1;36m배포 완료 → https://woojin-world.duckdns.org\033[0m\n'
