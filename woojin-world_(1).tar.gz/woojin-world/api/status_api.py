#!/usr/bin/env python3
"""
woojin-world status API
------------------------
서버가 자기 자신에 대해 이야기하기 위한 최소 API.

원칙:
  - 하드코딩된 숫자는 하나도 없다. 읽어올 수 없는 값은 null로 내려보내고
    프론트엔드에서 해당 항목을 숨긴다.
  - 표준 라이브러리만 사용한다 (pip 설치 불필요).
  - 127.0.0.1 에만 바인딩한다. 외부 노출은 nginx 리버스 프록시를 통해서만.

엔드포인트:
  GET /api/status  -> JSON
  GET /healthz     -> "ok"
"""

import json
import os
import re
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

LISTEN_HOST = os.environ.get("WW_HOST", "127.0.0.1")
LISTEN_PORT = int(os.environ.get("WW_PORT", "8099"))

# 방문 카운터를 보존할 경로. systemd StateDirectory=woojin-world 가 만들어 준다.
STATE_DIR = os.environ.get("WW_STATE_DIR", "/var/lib/woojin-world")
COUNTER_PATH = os.path.join(STATE_DIR, "counter")

# 사이트 소스가 git 저장소일 경우 커밋 해시를 읽어온다.
SITE_DIR = os.environ.get("WW_SITE_DIR", "/srv/woojin-world/site")

_counter_lock = threading.Lock()

# 자주 바뀌지 않는 값은 프로세스 시작 시 한 번만 조회한다.
_static_cache = {}
_static_cache_lock = threading.Lock()

# git 같은 서브프로세스 호출은 매 요청마다 돌리면 100ms 단위로 느려진다.
# 배포는 자주 일어나지 않으므로 짧은 TTL 캐시로 충분하다.
TTL_SECONDS = int(os.environ.get("WW_TTL", "30"))
_ttl_cache = {}
_ttl_cache_lock = threading.Lock()


def ttl_cached(key, producer):
    """producer()의 결과를 TTL_SECONDS 동안 재사용한다."""
    now = time.monotonic()
    with _ttl_cache_lock:
        entry = _ttl_cache.get(key)
        if entry and now - entry[0] < TTL_SECONDS:
            return entry[1]
    value = producer()
    with _ttl_cache_lock:
        _ttl_cache[key] = (now, value)
    return value


# --------------------------------------------------------------------------
# 개별 수집기. 실패하면 예외를 던지지 않고 None을 반환한다.
# --------------------------------------------------------------------------

def read_uptime_seconds():
    """/proc/uptime 첫 번째 필드 = 부팅 후 경과 초."""
    try:
        with open("/proc/uptime", "r") as fp:
            return float(fp.read().split()[0])
    except (OSError, ValueError, IndexError):
        return None


def read_loadavg():
    """1/5/15분 평균 부하."""
    try:
        with open("/proc/loadavg", "r") as fp:
            parts = fp.read().split()
        return [float(parts[0]), float(parts[1]), float(parts[2])]
    except (OSError, ValueError, IndexError):
        return None


def read_cpu_count():
    try:
        return os.cpu_count()
    except Exception:
        return None


def read_memory():
    """/proc/meminfo 기반. MemAvailable을 쓴다 (MemFree는 캐시를 제외해 오해를 부른다)."""
    try:
        info = {}
        with open("/proc/meminfo", "r") as fp:
            for line in fp:
                key, _, rest = line.partition(":")
                value = rest.strip().split()
                if value:
                    info[key] = int(value[0])  # kB 단위
        total = info.get("MemTotal")
        available = info.get("MemAvailable")
        if total is None or available is None:
            return None
        used = total - available
        return {
            "total_mb": round(total / 1024),
            "used_mb": round(used / 1024),
            "used_percent": round(used / total * 100, 1),
        }
    except (OSError, ValueError):
        return None


def read_disk(path="/"):
    try:
        usage = shutil.disk_usage(path)
        return {
            "total_gb": round(usage.total / 1024 ** 3, 1),
            "used_gb": round((usage.total - usage.free) / 1024 ** 3, 1),
            "used_percent": round((usage.total - usage.free) / usage.total * 100, 1),
        }
    except OSError:
        return None


def read_os_release():
    """PRETTY_NAME을 뽑아 'Rocky Linux 8.10' 같은 문자열로."""
    try:
        with open("/etc/os-release", "r") as fp:
            for line in fp:
                if line.startswith("PRETTY_NAME="):
                    return line.split("=", 1)[1].strip().strip('"')
    except OSError:
        pass
    return None


def read_kernel():
    try:
        return os.uname().release
    except Exception:
        return None


def read_nginx_version():
    """nginx -v 는 stderr로 출력한다."""
    binary = shutil.which("nginx")
    if not binary:
        return None
    try:
        result = subprocess.run(
            [binary, "-v"], capture_output=True, text=True, timeout=3
        )
        output = (result.stderr or "") + (result.stdout or "")
        match = re.search(r"nginx/(\S+)", output)
        return match.group(1) if match else None
    except (subprocess.SubprocessError, OSError):
        return None


def read_git_commit():
    """사이트 소스의 현재 커밋. git이 없거나 저장소가 아니면 None."""
    binary = shutil.which("git")
    if not binary or not os.path.isdir(SITE_DIR):
        return None
    try:
        result = subprocess.run(
            [binary, "-C", SITE_DIR, "rev-parse", "--short", "HEAD"],
            capture_output=True, text=True, timeout=3,
        )
        if result.returncode != 0:
            return None
        commit = result.stdout.strip()
        return commit or None
    except (subprocess.SubprocessError, OSError):
        return None


def read_last_deploy_epoch():
    """
    마지막 배포 시각.
    git 저장소면 마지막 커밋 시각, 아니면 사이트 디렉터리 mtime.
    """
    binary = shutil.which("git")
    if binary and os.path.isdir(SITE_DIR):
        try:
            result = subprocess.run(
                [binary, "-C", SITE_DIR, "log", "-1", "--format=%ct"],
                capture_output=True, text=True, timeout=3,
            )
            if result.returncode == 0 and result.stdout.strip():
                return int(result.stdout.strip())
        except (subprocess.SubprocessError, OSError, ValueError):
            pass
    try:
        return int(os.path.getmtime(SITE_DIR))
    except OSError:
        return None


def read_tls_protocol(header_value):
    """nginx가 proxy_set_header로 넘겨준 $ssl_protocol."""
    if not header_value or header_value == "-":
        return None
    return header_value


# --------------------------------------------------------------------------
# 방문 카운터
# --------------------------------------------------------------------------

# 카운터는 메모리에서 증가시키고 주기적으로만 디스크에 내린다.
# 요청마다 fsync를 하면 응답 시간이 디스크 지연에 묶인다.
FLUSH_EVERY = int(os.environ.get("WW_FLUSH_EVERY", "10"))

_counter_value = None      # 최초 요청 시 디스크에서 적재
_counter_unflushed = 0


def _load_counter():
    try:
        with open(COUNTER_PATH, "r") as fp:
            return int(fp.read().strip() or 0)
    except (OSError, ValueError):
        return 0


def _flush_counter(value):
    """임시 파일 + rename으로 원자적으로 교체. 부분 기록된 파일이 남지 않는다."""
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        tmp_path = "%s.tmp.%d" % (COUNTER_PATH, os.getpid())
        with open(tmp_path, "w") as fp:
            fp.write(str(value))
        os.replace(tmp_path, COUNTER_PATH)
        return True
    except OSError:
        # 디스크에 못 써도 서비스는 계속한다. 다음 재시작 때 값이 되돌아갈 뿐이다.
        return False


def bump_counter():
    """
    /api/status 응답 횟수를 누적한다.
    이 값은 '서버가 자기 상태를 답한 횟수'이지 정확한 방문자 수가 아니다.
    급작스러운 종료 시 최대 FLUSH_EVERY 건까지 유실될 수 있다 (의도된 trade-off).
    """
    global _counter_value, _counter_unflushed

    with _counter_lock:
        if _counter_value is None:
            _counter_value = _load_counter()

        _counter_value += 1
        _counter_unflushed += 1

        if _counter_unflushed >= FLUSH_EVERY:
            if _flush_counter(_counter_value):
                _counter_unflushed = 0

        return _counter_value


def flush_counter_on_exit():
    """정상 종료(systemd stop/restart) 시 잔여분을 반드시 기록한다."""
    with _counter_lock:
        if _counter_value is not None and _counter_unflushed:
            _flush_counter(_counter_value)


# --------------------------------------------------------------------------
# 응답 조립
# --------------------------------------------------------------------------

def get_static_facts():
    """프로세스 수명 동안 변하지 않는 값들을 캐시."""
    with _static_cache_lock:
        if not _static_cache:
            _static_cache.update({
                "os": read_os_release(),
                "kernel": read_kernel(),
                "hostname": socket.gethostname(),
                "cpu_count": read_cpu_count(),
                "nginx": read_nginx_version(),
                "python": "%d.%d.%d" % sys.version_info[:3],
            })
        return dict(_static_cache)


def build_status(tls_protocol=None):
    started = time.perf_counter()

    payload = get_static_facts()
    payload.update({
        "uptime_seconds": read_uptime_seconds(),
        "loadavg": read_loadavg(),
        "memory": read_memory(),
        "disk": read_disk("/"),
        "commit": ttl_cached("commit", read_git_commit),
        "last_deploy_epoch": ttl_cached("deploy", read_last_deploy_epoch),
        "tls_protocol": read_tls_protocol(tls_protocol),
        "served_count": bump_counter(),
        "server_time_epoch": int(time.time()),
    })

    # 서버 측 처리 시간. 네트워크 왕복은 클라이언트가 따로 잰다.
    payload["generation_ms"] = round((time.perf_counter() - started) * 1000, 2)
    return payload


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------

class StatusHandler(BaseHTTPRequestHandler):
    server_version = "woojin-world-status"
    sys_version = ""          # Python 버전을 Server 헤더로 흘리지 않는다
    protocol_version = "HTTP/1.1"

    def _respond(self, code, body, content_type):
        encoded = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(encoded)

    def do_GET(self):
        path = self.path.split("?", 1)[0].rstrip("/") or "/"

        if path == "/healthz":
            self._respond(200, "ok", "text/plain; charset=utf-8")
            return

        if path in ("/api/status", "/status", "/"):
            tls = self.headers.get("X-TLS-Protocol")
            try:
                payload = build_status(tls_protocol=tls)
            except Exception as exc:  # 한 항목이 터져도 500을 내지 않도록 방어
                self._respond(
                    500,
                    json.dumps({"error": str(exc)}),
                    "application/json; charset=utf-8",
                )
                return
            self._respond(
                200,
                json.dumps(payload, ensure_ascii=False),
                "application/json; charset=utf-8",
            )
            return

        self._respond(404, json.dumps({"error": "not found"}),
                      "application/json; charset=utf-8")

    def log_message(self, fmt, *args):
        # nginx access log와 중복되므로 침묵. 필요하면 이 줄을 지운다.
        pass


def main():
    server = ThreadingHTTPServer((LISTEN_HOST, LISTEN_PORT), StatusHandler)
    server.daemon_threads = True

    # systemd stop은 SIGTERM을 보낸다. 기본 동작은 즉시 종료라 카운터가 유실된다.
    def handle_term(signum, frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, handle_term)

    print("status api listening on %s:%d" % (LISTEN_HOST, LISTEN_PORT), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        flush_counter_on_exit()
        server.server_close()


if __name__ == "__main__":
    main()
