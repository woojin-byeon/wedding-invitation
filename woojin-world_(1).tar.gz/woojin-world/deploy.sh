#!/usr/bin/env bash
#
# woojin-world 설치 / 배포 스크립트
#
#   sudo ./deploy.sh install   최초 설치 (파일 배치 + systemd + nginx)
#   sudo ./deploy.sh update    사이트 파일만 갱신
#   sudo ./deploy.sh verify    설치 상태 점검
#
# 멱등하게 동작한다. 여러 번 실행해도 결과가 같다.

set -euo pipefail

APP_DIR="/srv/woojin-world"
SITE_DIR="${APP_DIR}/site"
API_DIR="${APP_DIR}/api"
SERVICE="woojin-status"
NGINX_CONF="/etc/nginx/conf.d/woojin-world.conf"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

c_ok()   { printf '\033[0;32m  ok\033[0m %s\n' "$1"; }
c_info() { printf '\033[0;36m  ->\033[0m %s\n' "$1"; }
c_warn() { printf '\033[0;33m  !!\033[0m %s\n' "$1"; }
c_err()  { printf '\033[0;31m  xx\033[0m %s\n' "$1" >&2; }

require_root() {
  if [[ ${EUID} -ne 0 ]]; then
    c_err "root 권한이 필요합니다: sudo $0 $*"
    exit 1
  fi
}

# --------------------------------------------------------------------------

install_files() {
  c_info "파일 배치: ${APP_DIR}"
  install -d -m 0755 "${SITE_DIR}" "${API_DIR}"

  # 사이트 정적 파일
  cp -a "${SRC_DIR}/site/." "${SITE_DIR}/"

  # 상태 API
  install -m 0755 "${SRC_DIR}/api/status_api.py" "${API_DIR}/status_api.py"

  # nginx는 정적 파일을 읽기만 하면 된다
  chmod -R a+rX "${SITE_DIR}"
  c_ok "파일 배치 완료"
}

install_service() {
  c_info "systemd 유닛 설치: ${SERVICE}"
  install -m 0644 "${SRC_DIR}/systemd/woojin-status.service" \
    "/etc/systemd/system/${SERVICE}.service"
  systemctl daemon-reload
  systemctl enable "${SERVICE}" >/dev/null
  systemctl restart "${SERVICE}"

  sleep 1
  if systemctl is-active --quiet "${SERVICE}"; then
    c_ok "${SERVICE} 기동됨"
  else
    c_err "${SERVICE} 기동 실패 — journalctl -u ${SERVICE} -n 40"
    exit 1
  fi
}

install_nginx() {
  if ! command -v nginx >/dev/null 2>&1; then
    c_warn "nginx가 없습니다. 설치 후 다시 실행하세요: sudo dnf install -y nginx"
    return
  fi

  c_info "nginx 설정 설치: ${NGINX_CONF}"
  install -m 0644 "${SRC_DIR}/nginx/woojin-world.conf" "${NGINX_CONF}"

  if nginx -t 2>/dev/null; then
    systemctl reload nginx 2>/dev/null || systemctl restart nginx
    c_ok "nginx 재적용 완료"
  else
    c_err "nginx 설정 오류. 되돌립니다."
    rm -f "${NGINX_CONF}"
    nginx -t
    exit 1
  fi
}

configure_selinux() {
  # Rocky/RHEL 기본값에서 SELinux가 enforcing이면
  # nginx가 (1) 웹 컨텐츠를 읽고 (2) 로컬 포트로 프록시하는 것을 막는다.
  command -v getenforce >/dev/null 2>&1 || return 0
  [[ "$(getenforce)" == "Enforcing" ]] || return 0

  c_info "SELinux Enforcing 감지 — 정책 적용"

  # nginx가 로컬 상태 API로 프록시할 수 있게
  if command -v setsebool >/dev/null 2>&1; then
    setsebool -P httpd_can_network_connect 1 || \
      c_warn "httpd_can_network_connect 설정 실패"
  fi

  # 사이트 디렉터리에 웹 컨텐츠 레이블 부여
  if command -v semanage >/dev/null 2>&1; then
    semanage fcontext -a -t httpd_sys_content_t "${SITE_DIR}(/.*)?" 2>/dev/null || true
    restorecon -R "${SITE_DIR}" >/dev/null 2>&1 || true
    c_ok "SELinux 레이블 적용"
  else
    c_warn "semanage 없음 — sudo dnf install -y policycoreutils-python-utils 후 재실행 권장"
  fi
}

open_firewall() {
  command -v firewall-cmd >/dev/null 2>&1 || return 0
  systemctl is-active --quiet firewalld || return 0

  c_warn "firewalld가 활성 상태입니다."
  c_warn "Cloudflare Tunnel을 쓴다면 포트를 열지 마세요 (인바운드 0이 목표)."
  c_warn "직접 노출한다면: sudo firewall-cmd --permanent --add-service=http --add-service=https && sudo firewall-cmd --reload"
}

verify() {
  local fail=0

  printf '\n== 점검 ==\n'

  if systemctl is-active --quiet "${SERVICE}"; then
    c_ok "${SERVICE} 실행 중"
  else
    c_err "${SERVICE} 미실행"; fail=1
  fi

  # 애플리케이션 계층 헬스체크. 포트 확인이 아니다.
  if curl -fsS --max-time 5 http://127.0.0.1:8099/healthz >/dev/null 2>&1; then
    c_ok "상태 API 응답 정상 (127.0.0.1:8099)"
  else
    c_err "상태 API 무응답"; fail=1
  fi

  if curl -fsS --max-time 5 http://127.0.0.1:8099/api/status 2>/dev/null \
      | grep -q '"uptime_seconds"'; then
    c_ok "/api/status 페이로드 정상"
  else
    c_err "/api/status 페이로드 이상"; fail=1
  fi

  if command -v nginx >/dev/null 2>&1; then
    if curl -fsS --max-time 5 -H "Host: woojin-world.duckdns.org" \
        http://127.0.0.1/ 2>/dev/null | grep -q "woojin-world"; then
      c_ok "nginx가 사이트를 서빙 중"
    else
      c_warn "nginx를 통한 접근 확인 실패 (server_name 불일치일 수 있음)"
    fi
  fi

  printf '\n'
  if [[ ${fail} -eq 0 ]]; then
    c_ok "전체 정상"
  else
    c_err "문제 발견 — journalctl -u ${SERVICE} -n 40"
    return 1
  fi
}

# --------------------------------------------------------------------------

case "${1:-}" in
  install)
    require_root "$@"
    install_files
    install_service
    configure_selinux
    install_nginx
    open_firewall
    verify
    printf '\n다음: 브라우저에서 접속해 상단 숫자가 채워지는지 확인하세요.\n'
    ;;
  update)
    require_root "$@"
    install_files
    systemctl restart "${SERVICE}"
    verify
    ;;
  verify)
    verify
    ;;
  *)
    cat <<EOF
사용법:
  sudo $0 install   최초 설치
  sudo $0 update    사이트 파일 갱신
  sudo $0 verify    상태 점검
EOF
    exit 1
    ;;
esac
