/* woojin-world
   /api/status를 받아 서버의 실제 상태를 렌더링한다.

   원칙: 값이 null이면 그 항목을 통째로 숨긴다.
   가짜 숫자를 채우는 순간 이 사이트의 유일한 무기가 사라진다. */

(function () {
  "use strict";

  var REFRESH_MS = 15000;

  function $(sel) { return document.querySelector(sel); }

  /* ---------- 포매터 ---------- */

  function fmtUptime(seconds) {
    if (seconds == null) return null;
    var s = Math.floor(seconds);
    var d = Math.floor(s / 86400);
    var h = Math.floor((s % 86400) / 3600);
    var m = Math.floor((s % 3600) / 60);
    if (d > 0) return d + "d " + h + "h";
    if (h > 0) return h + "h " + m + "m";
    return m + "m";
  }

  function fmtAgo(epoch, nowEpoch) {
    if (epoch == null) return null;
    var diff = Math.max(0, (nowEpoch || Math.floor(Date.now() / 1000)) - epoch);
    if (diff < 3600) return Math.max(1, Math.floor(diff / 60)) + "분 전";
    if (diff < 86400) return Math.floor(diff / 3600) + "시간 전";
    return Math.floor(diff / 86400) + "일 전";
  }

  function fmtCount(n) {
    if (n == null) return null;
    return n.toLocaleString("ko-KR");
  }

  /* ---------- 렌더링 ---------- */

  /* 항목 하나를 그린다. value가 null이면 아무것도 그리지 않는다. */
  function part(label, value, unit) {
    if (value === null || value === undefined) return "";
    return '<span class="item">' + label +
           ' <span class="v">' + value + (unit || "") + "</span></span>";
  }

  function joinParts(parts) {
    var kept = parts.filter(function (p) { return p !== ""; });
    return kept.join('<span class="sep">·</span>');
  }

  function renderVitals(d, rttMs) {
    var el = $("#vitals");
    if (!el) return;

    var line1 = joinParts([
      part("", (d.os || "Linux"), ""),
      part("uptime", fmtUptime(d.uptime_seconds), ""),
      part("load", d.loadavg ? d.loadavg[0].toFixed(2) : null, ""),
      part("mem", d.memory ? d.memory.used_percent : null, "%"),
      part("disk", d.disk ? d.disk.used_percent : null, "%")
    ]);

    var line2 = joinParts([
      part("응답", rttMs != null ? rttMs : null, "ms"),
      part("이 페이지는", fmtCount(d.served_count), "번째 응답입니다")
    ]);

    el.innerHTML =
      '<div><span class="pulse"></span>' + line1 + "</div>" +
      (line2 ? "<div>" + line2 + "</div>" : "");

    // 갱신된 값에 짧게 색을 넣어 '살아있음'을 드러낸다
    var vs = el.querySelectorAll(".v");
    for (var i = 0; i < vs.length; i++) vs[i].classList.add("tick");
    setTimeout(function () {
      for (var j = 0; j < vs.length; j++) vs[j].classList.remove("tick");
    }, 90);
  }

  function renderFooter(d) {
    var el = $("#footer-facts");
    if (!el) return;

    var parts = [
      d.nginx ? "nginx/" + d.nginx : null,
      d.tls_protocol,
      d.commit ? "commit " + d.commit : null,
      d.last_deploy_epoch
        ? "배포 " + fmtAgo(d.last_deploy_epoch, d.server_time_epoch)
        : null,
      d.kernel ? "kernel " + d.kernel : null
    ].filter(function (p) { return p; });

    el.innerHTML = parts.join('<span class="sep">·</span>');
  }

  function renderError() {
    var el = $("#vitals");
    if (!el) return;
    el.innerHTML =
      '<span style="opacity:.6">상태 API에 연결할 수 없습니다. ' +
      "서버는 정적 파일만 응답하고 있습니다.</span>";
  }

  /* ---------- 폴링 ---------- */

  var inFlight = false;

  function poll() {
    if (inFlight) return;
    if (document.hidden) return;   // 백그라운드 탭에서는 서버를 괴롭히지 않는다

    inFlight = true;
    var t0 = performance.now();

    fetch("/api/status", { cache: "no-store" })
      .then(function (res) {
        if (!res.ok) throw new Error("HTTP " + res.status);
        return res.json();
      })
      .then(function (data) {
        var rtt = Math.round(performance.now() - t0);
        renderVitals(data, rtt);
        renderFooter(data);
      })
      .catch(renderError)
      .then(function () { inFlight = false; });
  }

  poll();
  setInterval(poll, REFRESH_MS);

  // 탭으로 돌아오면 즉시 한 번 갱신
  document.addEventListener("visibilitychange", function () {
    if (!document.hidden) poll();
  });
})();
