#!/usr/bin/env python3
"""
로컬 검증용 게이트웨이.
nginx가 하는 일(정적 서빙 + /api/ 프록시 + try_files)을 흉내 내
서버 없이도 사이트 전체를 확인할 수 있게 한다.

  python3 test/local_gateway.py
  -> http://127.0.0.1:8080

주의: 검증 전용이다. 실제 서비스는 nginx로 한다.
"""
import os
import sys
import urllib.request
import urllib.error
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "site")
ROOT = os.path.normpath(ROOT)
API = "http://127.0.0.1:8099"
PORT = int(os.environ.get("GW_PORT", "8080"))


class Gateway(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=ROOT, **kw)

    def do_GET(self):
        path = self.path.split("?", 1)[0]

        # nginx의 location /api/ 프록시에 해당
        if path.startswith("/api/") or path == "/healthz":
            try:
                req = urllib.request.Request(API + path)
                req.add_header("X-TLS-Protocol", "TLSv1.3")  # nginx가 넣어주는 헤더
                with urllib.request.urlopen(req, timeout=3) as resp:
                    body = resp.read()
                    self.send_response(resp.status)
                    self.send_header("Content-Type",
                                     resp.headers.get("Content-Type", "application/json"))
                    self.send_header("Content-Length", str(len(body)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    self.wfile.write(body)
            except Exception as exc:
                msg = ('{"error":"upstream unavailable"}').encode()
                self.send_response(502)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(msg)))
                self.end_headers()
                self.wfile.write(msg)
            return

        # nginx의 try_files $uri $uri/ $uri/index.html
        fs = os.path.normpath(os.path.join(ROOT, path.lstrip("/")))
        if os.path.isdir(fs) and not path.endswith("/"):
            self.send_response(301)
            self.send_header("Location", path + "/")
            self.end_headers()
            return

        return super().do_GET()

    def log_message(self, fmt, *args):
        sys.stderr.write("  gw: %s\n" % (fmt % args))


if __name__ == "__main__":
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Gateway)
    srv.daemon_threads = True
    print("gateway on http://127.0.0.1:%d (root=%s)" % (PORT, ROOT), flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
